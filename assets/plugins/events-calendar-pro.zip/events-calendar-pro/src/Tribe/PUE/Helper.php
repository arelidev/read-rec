<?php

class Tribe__Events__Pro__PUE__Helper {

	/**
	 * @var string Helper data
	 */
	const DATA = 'f180afdcd035f7ca2255608e4031ced95760f16a';

}
