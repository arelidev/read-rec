<?php

class Tribe__Tickets_Plus__PUE__Helper {

	/**
	 * @var string Helper data
	 */
	const DATA = '';

}
