<button class="accordion-header tribe_attendee_meta">
	<?php esc_html_e( 'Attendee Information', 'event-tickets-plus' ); ?>
</button>
<section class="accordion-content">
	<?php include tribe( 'tickets-plus.main' )->plugin_path . 'src/admin-views/meta-content.php' ?>
</section>
