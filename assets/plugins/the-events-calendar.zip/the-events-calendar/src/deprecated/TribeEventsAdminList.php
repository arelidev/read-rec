<?php
	_deprecated_file( __FILE__, '3.10', 'Tribe__Events__Admin_List' );


	class TribeEventsAdminList extends Tribe__Events__Admin_List {

	}