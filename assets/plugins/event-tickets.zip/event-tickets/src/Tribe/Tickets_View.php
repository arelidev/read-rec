<?php
// don't load directly
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

class Tribe__Tickets__Tickets_View {

	/**
	 * Get (and instantiate, if necessary) the instance of the class.
	 *
	 * @static
	 * @return self
	 *
	 */
	public static function instance() {
		static $instance;

		if ( ! $instance instanceof self ) {
			$instance = new self;
		}

		return $instance;
	}

	/**
	 * Hook the necessary filters and Actions!
	 *
	 * @static
	 * @return self
	 */
	public static function hook() {
		$myself = self::instance();

		add_action( 'template_redirect', [ $myself, 'authorization_redirect' ] );
		add_action( 'template_redirect', [ $myself, 'update_tickets' ] );

		// Generate Non TEC Permalink.
		add_action( 'generate_rewrite_rules', [ $myself, 'add_non_event_permalinks' ] );
		add_filter( 'query_vars', [ $myself, 'add_query_vars' ] );
		add_action( 'parse_request', [ $myself, 'prevent_page_redirect' ] );
		add_filter( 'the_content', [ $myself, 'intercept_content' ] );
		add_action( 'parse_request', [ $myself, 'maybe_regenerate_rewrite_rules' ] );
		add_filter( 'tribe_events_views_v2_bootstrap_should_display_single', [ $myself, 'intercept_views_v2_single_display' ], 15, 4 );

		// Only Applies this to TEC users.
		if ( class_exists( 'Tribe__Events__Rewrite' ) ) {
			add_action( 'tribe_events_pre_rewrite', [ $myself, 'add_permalink' ] );
			add_filter( 'tribe_events_rewrite_base_slugs', [ $myself, 'add_rewrite_base_slug' ] );
		}

		// Intercept Template file for Tickets.
		add_action( 'pre_get_posts', [ $myself, 'modify_ticket_display_query' ] );
		add_filter( 'tribe_events_template_single-event.php', [ $myself, 'intercept_template' ], 20 );

		// We will inject on the Priority 4, to be happen before RSVP.
		add_action( 'tribe_events_single_event_after_the_meta', [ $myself, 'inject_link_template' ], 4 );
		add_filter( 'the_content', [ $myself, 'inject_link_template_the_content' ], 9 );

		return $myself;
	}

	/**
	 * By default WordPress has a nasty if query_var['p'] is a page then redirect to the page,
	 * so we will change the variables accordingly.
	 *
	 * @param  WP_Query $query The current Query.
	 * @return void
	 */
	public function prevent_page_redirect( $query ) {
		$is_correct_page = isset( $query->query_vars['tribe-edit-orders'] ) && $query->query_vars['tribe-edit-orders'];

		if ( ! $is_correct_page ) {
			return;
		}

		// This has no Performance problems, since get_post uses caching and we use this method later on.
		$post = isset( $query->query_vars['p'] ) ? get_post( absint( $query->query_vars['p'] ) ) : 0;
		if ( ! $post ) {
			return;
		}

		if ( ! tribe_tickets_post_type_enabled( $post->post_type ) ) {
			return;
		}

		$query->query_vars['post_type'] = $post->post_type;

		if ( 'page' === $post->post_type ) {
			// Set `page_id` for faster query.
			$query->query_vars['page_id'] = $post->ID;
		}

	}

	/**
	 * Tries to Flush the Rewrite rules.
	 *
	 * @return void
	 */
	public function maybe_regenerate_rewrite_rules() {
		// if they don't have any rewrite rules, do nothing
		// Don't try to run stuff for non-logged users (too time consuming)
		if ( ! is_array( $GLOBALS['wp_rewrite']->rules ) || ! is_user_logged_in() ) {
			return;
		}

		$rules = $this->rewrite_rules_array();

		$diff = array_diff( $rules, $GLOBALS['wp_rewrite']->rules );
		$key_diff = array_diff_assoc( $rules, $GLOBALS['wp_rewrite']->rules );

		if ( empty( $diff ) && empty( $key_diff ) ) {
			return;
		}

		flush_rewrite_rules();
	}

	/**
	 * Gets the List of Rewrite rules we are using here.
	 *
	 * @return array
	 */
	public function rewrite_rules_array() {
		$bases = $this->add_rewrite_base_slug();

		$rules = [
			sanitize_title_with_dashes( $bases['tickets'][0] ) . '/([0-9]{1,})/?' => 'index.php?p=$matches[1]&tribe-edit-orders=1',
		];

		return $rules;
	}

	/**
	 * For non events the links will be a little bit weird, but it's the safest way.
	 *
	 * @param WP_Rewrite $wp_rewrite
	 */
	public function add_non_event_permalinks( WP_Rewrite $wp_rewrite  ) {
		$wp_rewrite->rules = $this->rewrite_rules_array() + $wp_rewrite->rules;
	}

	/**
	 * Register a new public (URL query parameters can use it) Query Var to allow tickets editing.
	 *
	 * @see \WP::parse_request()
	 *
	 * @param array $vars
	 *
	 * @return array
	 */
	public function add_query_vars( $vars ) {
		$vars[] = 'tribe-edit-orders';
		return $vars;
	}


	/**
	 * Sort Attendee by Order Status to Process Not Going First.
	 *
	 * @since 4.7.1
	 *
	 * @param $a array An array of ticket id and status.
	 * @param $b array An array of ticket id and status.
	 *
	 * @return int
	 */
	public function sort_attendees( $a, $b ) {
		return strcmp( $a['order_status'], $b['order_status'] );
	}

	/**
	 * Update the RSVP and Tickets values for each Attendee.
	 */
	public function update_tickets() {
		$is_correct_page = $this->is_edit_page();

		// Now fetch the display and check it
		if (
			'tickets' !== get_query_var( 'eventDisplay', false )
			&& ! $is_correct_page
		) {
			return;
		}

		if (
			empty( $_POST['process-tickets'] )
			|| (
				empty( $_POST['attendee'] )
				&& empty( $_POST['tribe-tickets-meta'] )
			)
		) {
			return;
		}

		$post_id = get_the_ID();

		$attendees = ! empty( $_POST['attendee'] ) ? $_POST['attendee'] : [];

		/**
		 * Sort list to handle all not attending first
		 *
		 * @todo switch to only wp_list_sort once WordPress 4.7 is minimum supported version
		 */
		if ( function_exists( 'wp_list_sort' ) ) {
			$attendees = wp_list_sort( $attendees, 'order_status', 'ASC', true );
		} else {
			uasort( $attendees, [ $this, 'sort_attendees' ] );
		}

		foreach ( $attendees as $order_id => $data ) {
			/**
			 * An Action fired for each one of the Attendees that were posted on the Order Tickets page
			 *
			 * @var array $data     Information that we are trying to save.
			 * @var int   $order_id ID of attendee ticket.
			 * @var int   $post_id  ID of event.
			 */
			do_action( 'event_tickets_attendee_update', $data, $order_id, $post_id );
		}

		/**
		 * A way for Meta to be saved, because it's grouped in a different way
		 *
		 * @param int $post_id ID of event
		 */
		do_action( 'event_tickets_after_attendees_update', $post_id );

		// After editing the values, we update the transient.
		Tribe__Post_Transient::instance()->delete( $post_id, Tribe__Tickets__Tickets::ATTENDEES_CACHE );

		// If it's not events CPT
		$url = $this->get_tickets_page_url( $post_id, ! $is_correct_page );
		$url = add_query_arg( 'tribe_updated', 1, $url );
		wp_safe_redirect( esc_url_raw( $url ) );
		exit;
	}

	/**
	 * Helper function to generate the Link to the tickets page of an event.
	 *
	 * @since 4.7.1
	 *
	 * @param $event_id
	 * @param $is_event_page
	 *
	 * @return string|void
	 */
	public function get_tickets_page_url( $event_id, $is_event_page ) {
		$has_plain_permalink = '' === get_option( 'permalink_structure' );
		$event_url = get_permalink( $event_id );

		// Is on the Event post type
		if ( $is_event_page ) {
			$link = $has_plain_permalink
				? add_query_arg( 'eventDisplay', 'tickets', untrailingslashit( $event_url ) )
				: trailingslashit( $event_url ) . 'tickets';
		} else {
			$link = $has_plain_permalink
				? add_query_arg( 'tribe-edit-orders', 1, untrailingslashit( $event_url ) )
				: home_url( '/tickets/' . $event_id );
		}

		return $link;
	}

	/**
	 * Makes sure only logged users can See the Tickets page.
	 *
	 * @return void
	 */
	public function authorization_redirect() {
		/**
		 * @todo Remove this after we implement the Rewrites in Common
		 */
		$is_event_query = ! empty( $GLOBALS['wp_query']->tribe_is_event_query );

		// When it's not Events Query and we have TEC active we dont care
		if ( class_exists( 'Tribe__Events__Main' ) && ! $is_event_query ) {
			return;
		}

		// If we got here and it's a 404 + single
		if ( is_single() && is_404() ) {
			return;
		}

		// Now fetch the display and check it
		if ( 'tickets' !== get_query_var( 'eventDisplay', false ) && ! $this->is_edit_page() ) {
			return;
		}

		// Only goes to the Redirect if user is not logged in
		if ( is_user_logged_in() ) {
			return;
		}

		// Loop back to the Event, this page is only for Logged users
		wp_redirect( get_permalink() );
		exit;
	}

	/**
	 * To allow `tickets` to be translatable we need to add it as a base.
	 *
	 * @param  array $bases The translatable bases.
	 * @return array
	 */
	public function add_rewrite_base_slug( $bases = [] ) {
		/**
		 * Allows users to filter and change the base for the order page
		 *
		 * @param string $slug
		 * @param array  $bases
		 */
		$bases['tickets'] = (array) apply_filters( 'event_tickets_rewrite_slug_orders_page', 'tickets', $bases );

		return $bases;
	}


	/**
	 * Checks if this is the ticket page based on the current query var.
	 *
	 * This only works after parse_query has run.
	 *
	 * @return bool
	 */
	public function is_edit_page() {
		return false !== get_query_var( 'tribe-edit-orders', false );
	}

	/**
	 * Adds the Permalink for the tickets end point.
	 *
	 * @param Tribe__Events__Rewrite $rewrite
	 */
	public function add_permalink( Tribe__Events__Rewrite $rewrite ) {

		// Adds the 'tickets' endpoint for single event pages.
		$rewrite->single(
			[ '{{ tickets }}' ],
			[
				Tribe__Events__Main::POSTTYPE => '%1',
				'post_type' => Tribe__Events__Main::POSTTYPE,
				'eventDisplay' => 'tickets',
			]
		);

		// Adds the `tickets` endpoint for recurring events
		$rewrite->single(
			[ '(\d{4}-\d{2}-\d{2})', '{{ tickets }}' ],
			[
				Tribe__Events__Main::POSTTYPE => '%1',
				'eventDate' => '%2',
				'post_type' => Tribe__Events__Main::POSTTYPE,
				'eventDisplay' => 'tickets',
			]
		);

	}

	/**
	 * Filter to make sure Tickets eventDisplay properly displays the Tickets page.
	 *
	 * @since 4.11.2
	 *
	 * @param bool   $should_display_single If we should display single or not.
	 * @param string $view_slug             Which view slug we are working with.
	 *
	 * @return bool
	 */
	public function intercept_views_v2_single_display( $should_display_single, $view_slug ) {
		if ( 'tickets' === $view_slug ) {
			return true;
		}

		return $should_display_single;
	}

	/**
	 * Intercepts the_content from the posts to include the orders structure.
	 *
	 * @since 4.11.2 Avoid running when it shouldn't by bailing if not in main query loop on a single post.
	 *
	 * @param string $content Normally the_content of a post.
	 *
	 * @return string
	 */
	public function intercept_content( $content = '' ) {
		// Now fetch the display and check it
		$display = get_query_var( 'eventDisplay', false );

		// Prevents firing more than it needs to outside of the loop.
		if (
			! is_single()
			|| ! in_the_loop()
			|| ! is_main_query()
			|| (
				'tickets' !== $display
				&& ! $this->is_edit_page()
			)
		) {
			return $content;
		}

		ob_start();

		include Tribe__Tickets__Templates::get_template_hierarchy( 'tickets/orders.php' );

		$content = ob_get_clean();

		return $content;
	}

	/**
	 * Modify the front end ticket list display for it to always display
	 * even when Hide From Event Listings is checked for an event.
	 *
	 * @since 4.7.3
	 *
	 * @param $query WP_Query Query object.
	 *
	 */
	public function modify_ticket_display_query( $query ) {
		if ( empty( $query->tribe_is_event_query ) ) {
			return;
		}

		if ( 'tickets' !== get_query_var( 'eventDisplay', false ) ) {
			return;
		}

		$query->set( 'post__not_in', '' );

		// Do not attempt to filter the query for this custom view.
		$query->set( 'tribe_suppress_query_filters', true );
	}

	/**
	 * We need to intercept the template loading and load the correct file.
	 *
	 * @param string $old_file Non important variable with the previous path.
	 *
	 * @return string          The correct File path for the tickets endpoint.
	 */
	public function intercept_template( $old_file ) {
		global $wp_query;

		/**
		 * @todo Remove this after we implement the Rewrites in Common
		 */
		$is_event_query = ! empty( $wp_query->tribe_is_event_query );

		// When it's not our query we don't care
		if ( ! $is_event_query ) {
			return $old_file;
		}

		// If we got here and it's a 404 + single
		if ( is_single() && is_404() ) {
			return $old_file;
		}

		// Now fetch the display and check it
		$display = get_query_var( 'eventDisplay', false );

		if ( 'tickets' !== $display && ! $this->is_edit_page() ) {
			return $old_file;
		}

		// Fetch the correct file using the Tickets Hierarchy
		$file = Tribe__Tickets__Templates::get_template_hierarchy( 'tickets/orders.php' );

		return $file;
	}

	/**
	 * Injects the Link to The front-end Tickets page normally
	 * at `tribe_events_single_event_after_the_meta`.
	 *
	 * @return void
	 */
	public function inject_link_template() {
		/**
		 * A flag we can set via filter, e.g. at the end of this method, to ensure this template only shows once.
		 *
		 * @since 4.5.6
		 *
		 * @param boolean $already_rendered Whether the order link template has already been rendered.
		 */
		$already_rendered = apply_filters( 'tribe_tickets_order_link_template_already_rendered', false );

		if ( $already_rendered ) {
			return;
		}

		$event_id = get_the_ID();
		$user_id  = get_current_user_id();

		if ( ! $this->has_rsvp_attendees( $event_id, $user_id ) && ! $this->has_ticket_attendees( $event_id, $user_id ) ) {
			return;
		}

		if ( $this->is_edit_page() ) {
			return;
		}

		if ( ! tribe_tickets_post_type_enabled( get_post_type() ) ) {
			return;
		}

		$file = Tribe__Tickets__Templates::get_template_hierarchy( 'tickets/orders-link.php' );

		/**
		 * @since 4.10.8 Attempt to load from old location to account for pre-existing theme overrides. If not found,
		 *            go through the motions with the new location.
		 */
		if ( empty( $file ) ) {
			$file = Tribe__Tickets__Templates::get_template_hierarchy( 'tickets/view-link.php' );
		}

		include $file;

		add_filter( 'tribe_tickets_order_link_template_already_rendered', '__return_true' );
	}

	/**
	 * Injects the Link to The front-end Tickets page to non Events.
	 *
	 * @param string $content  The content form the post.
	 * @return string $content
	 */
	public function inject_link_template_the_content( $content ) {
		// Prevents firing more then it needs too outside of the loop
		$in_the_loop = isset( $GLOBALS['wp_query']->in_the_loop ) && $GLOBALS['wp_query']->in_the_loop;

		$post_id = get_the_ID();
		$user_id = get_current_user_id();

		// if the current post type doesn't have tickets enabled for it, bail
		if ( ! tribe_tickets_post_type_enabled( get_post_type( $post_id ) ) ) {
			return $content;
		}

		/**
		 * @todo Remove this after we implement the Rewrites in Common
		 */
		$is_event_query = ! empty( $GLOBALS['wp_query']->tribe_is_event_query );

		// When it's not our query we don't care
		if ( ( class_exists( 'Tribe__Events__Main' ) && $is_event_query ) || ! $in_the_loop ) {
			return $content;
		}

		// If we have this we are already on the tickets page
		if ( $this->is_edit_page() ) {
			return $content;
		}

		if ( ! $this->has_rsvp_attendees( $post_id, $user_id ) && ! $this->has_ticket_attendees( $post_id, $user_id ) ) {
			return $content;
		}

		ob_start();

		$file = Tribe__Tickets__Templates::get_template_hierarchy( 'tickets/orders-link.php' );

		/**
		 * @since 4.10.8 Attempt to load from old location to account for pre-existing theme overrides. If not found,
		 *            go through the motions with the new location.
		 */
		if ( empty( $file ) ) {
			$file = Tribe__Tickets__Templates::get_template_hierarchy( 'tickets/view-link.php' );
		}

		include $file;

		$content .= ob_get_clean();

		add_filter( 'tribe_tickets_order_link_template_already_rendered', '__return_true' );

		return $content;
	}

	/**
	 * Fetches from the Cached attendees list the ones that are relevant for this user and event.
	 * Important to note that this method will return the attendees organized by order id.
	 *
	 * @param  int       $event_id      The Event ID we're checking.
	 * @param  int|null  $user_id       An Optional User ID.
	 * @param  boolean   $include_rsvp  If this should include RSVP, default is false.
	 * @return array                    List of Attendees grouped by order id.
	 */
	public function get_event_attendees_by_order( $event_id, $user_id = null, $include_rsvp = false ) {
		if ( ! $user_id ) {
			$attendees = Tribe__Tickets__Tickets::get_event_attendees( $event_id );
		} else {
			// If we have a user_id then limit by that.
			$args = [
				'by' => [
					'user' => $user_id,
				],
			];

			$attendee_data = Tribe__Tickets__Tickets::get_event_attendees_by_args( $event_id, $args );

			$attendees = $attendee_data['attendees'];
		}

		$orders = [];

		foreach ( $attendees as $key => $attendee ) {
			// Ignore RSVP if we don't tell it specifically
			if ( 'rsvp' === $attendee['provider_slug'] && ! $include_rsvp ) {
				continue;
			}

			$orders[ (int) $attendee['order_id'] ][] = $attendee;
		}

		return $orders;
	}

	/**
	 * Fetches from the Cached attendees list the ones that are relevant for this user and event.
	 * Important to note that this method will return the attendees from RSVP.
	 *
	 * @param  int       $event_id     The Event ID we're checking.
	 * @param  int|null  $user_id      An Optional User ID.
	 * @return array                   Array with the RSVP attendees.
	 */
	public function get_event_rsvp_attendees( $event_id, $user_id = null ) {
		$attendees = [];

		/** @var Tribe__Tickets__RSVP $rsvp */
		$rsvp = tribe( 'tickets.rsvp' );

		if ( ! $user_id ) {
			return $rsvp->get_attendees_by_id( $event_id );
		}

		return $rsvp->get_attendees_by_user_id( $user_id, $event_id );
	}

	/**
	 * Groups RSVP attendees by purchaser name/email.
	 *
	 * @param int $event_id The Event ID we're checking.
	 * @param int|null $user_id An optional user ID.
	 * @return array Array with the RSVP attendees grouped by purchaser name/email.
	 */
	public function get_event_rsvp_attendees_by_purchaser( $event_id, $user_id = null ) {
		$attendees = $this->get_event_rsvp_attendees( $event_id, $user_id );

		if ( ! $attendees ) {
			return [];
		}

		$attendee_groups = [];
		foreach ( $attendees as $attendee ) {
			$key = $attendee['purchaser_name'] . '::' . $attendee['purchaser_email'];

			if ( ! isset( $attendee_groups[ $key ] ) ) {
				$attendee_groups[ $key ] = [];
			}

			$attendee_groups[ $key ][] = $attendee;
		}

		return $attendee_groups;
	}

	/**
	 * Gets a List of Possible RSVP answers.
	 *
	 * @param string $selected    Allows users to check if an option exists or get it's label.
	 * @param bool   $just_labels Whether just the options labels should be returned.
	 *
	 * @return array|bool An array containing the RSVP states, an array containing the selected
	 *                    option data or `false` if the selected option does not exist.
	 */
	public function get_rsvp_options( $selected = null, $just_labels = true ) {
		/** @var Tribe__Tickets__Status__Manager $status_mgr */
		$status_mgr = tribe( 'tickets.status' );

		$options = $status_mgr->get_status_options( 'rsvp' );

		/**
		 * Allow users to add more RSVP options.
		 *
		 * Additional RSVP options should be specified in the following formats:
		 *
		 *      [
		 *          'slug' => 'Option 1 label',
		 *          'slug' => [ 'label' => 'Option 3 label' ],
		 *          'slug' => [ 'label' => 'Option 2 label', 'decrease_stock_by' => 1 ],
		 *      ]
		 *
		 * The `decrease_stock_by` key can be omitted and will default to `1`.
		 *
		 * @param array $options
		 * @param string $selected
		 */
		$options = apply_filters( 'event_tickets_rsvp_options', $options, $selected );

		$options = array_filter( $options, [ $this, 'has_rsvp_format' ] );
		array_walk( $options, [ $this, 'normalize_rsvp_option' ] );

		// If an option was passed return it's label, but if doesn't exist return false
		if ( null !== $selected ) {
			return isset( $options[ $selected  ] ) ?
                $options[ $selected  ]['label'] : false;
		}

		return $just_labels ?
			array_combine( array_keys( $options ), wp_list_pluck( $options, 'label' ) )
			: $options;
	}

	/**
	 * Check if the RSVP option is a valid one.
	 *
	 * @param  string  $option Which rsvp option to check.
	 * @return boolean
	 */
	public function is_valid_rsvp_option( $option ) {
		return in_array( $option, array_keys( $this->get_rsvp_options() ) );
	}

	/**
	 * Counts the amount of RSVP attendees.
	 *
	 * @param int      $event_id The Event ID we're checking.
	 * @param int|null $user_id  An Optional User ID.
	 *
	 * @return int
	 */
	public function count_rsvp_attendees( $event_id, $user_id = null ) {
		if ( ! $user_id && null !== $user_id ) {
			// No attendees for this user.
			return 0;
		}

		/** @var Tribe__Tickets__RSVP $rsvp */
		$rsvp = tribe( 'tickets.rsvp' );

		// Get total attendees count for all users.
		if ( ! $user_id ) {
			return $rsvp->get_attendees_count( $event_id );
		}

		// Get total attendees count for this user.
		return $rsvp->get_attendees_count_by_user( $event_id, $user_id );
	}

	/**
	 * Counts the Amount of Tickets attendees.
	 *
	 * @param  int       $event_id     The Event ID we're checking.
	 * @param  int|null  $user_id      An Optional User ID.
	 * @return int
	 */
	public function count_ticket_attendees( $event_id, $user_id = null ) {
		if ( ! $user_id && null !== $user_id ) {
			// No attendees for this user.
			return 0;
		}

		$args = [
			'by' => [
				'provider__not_in' => 'rsvp',
			],
		];

		// Get total attendees count for this user.
		if ( $user_id ) {
			$args['by']['user'] = $user_id;
		}

		return Tribe__Tickets__Tickets::get_event_attendees_count( $event_id, $args );
	}

	/**
	 * Verifies if we have RSVP attendees for this user and event.
	 *
	 * @param  int       $event_id     The Event ID we're checking.
	 * @param  int|null  $user_id      An Optional User ID.
	 * @return int
	 */
	public function has_rsvp_attendees( $event_id, $user_id = null ) {
		$rsvp_orders = $this->count_rsvp_attendees( $event_id, $user_id );
		return ! empty( $rsvp_orders );
	}

	/**
	 * Verifies if we have Tickets attendees for this user and event
	 *
	 * @param  int       $event_id     The Event ID we're checking.
	 * @param  int|null  $user_id      An Optional User ID.
	 * @return int
	 */
	public function has_ticket_attendees( $event_id, $user_id = null ) {
		$ticket_orders = $this->count_ticket_attendees( $event_id, $user_id );
		return ! empty( $ticket_orders );
	}

	/**
	 * Gets the name(s) of the type(s) of ticket(s) the specified user (optional) has for the specified event.
	 *
	 * @since 4.2
	 * @since 4.10.8 Deprecated the 3rd parameter (whether or not to use 'plurals') in favor of figuring it out per type.
	 *
	 * @param int      $event_id   The Event ID we're checking.
	 * @param int|null $user_id    An optional User ID.
	 * @param null     $deprecated Deprecated argument.
	 *
	 * @return string
	 */
	public function get_description_rsvp_ticket( $event_id, $user_id = null, $deprecated = null ) {
		$descriptions = [];

		$rsvp_count = $this->count_rsvp_attendees( $event_id, $user_id );

		$ticket_count = $this->count_ticket_attendees( $event_id, $user_id );

		if ( 1 === $rsvp_count ) {
			$descriptions[] = tribe_get_rsvp_label_singular( 'tickets_view_description' );
		} elseif ( 1 < $rsvp_count ) {
			$descriptions[] = tribe_get_rsvp_label_plural( 'tickets_view_description' );
		}

		if ( 1 === $ticket_count ) {
			$descriptions[] = tribe_get_ticket_label_singular( 'tickets_view_description' );
		} elseif ( 1 < $ticket_count ) {
			$descriptions[] = tribe_get_ticket_label_plural( 'tickets_view_description' );
		}

		// Just return false if array is empty
		if ( empty( $descriptions ) ) {
			return '';
		}

		return esc_html( implode( _x( ' and ', 'separator if there are both RSVPs and Tickets', 'event-tickets' ), $descriptions ) );
	}

	/**
	 * Creates the HTML for the Select Element for RSVP options.
	 *
	 * @param  string $name     The Name of the Field.
	 * @param  string $selected The Current selected option.
	 * @param  int  $event_id   The Event/Post ID (optional).
	 * @param  int  $ticket_id  The Ticket/RSVP ID (optional).
	 * @return void
	 */
	public function render_rsvp_selector( $name, $selected, $event_id = null, $ticket_id = null ) {
		$options = $this->get_rsvp_options();

		?>
		<select <?php echo $this->get_restriction_attr( $event_id, $ticket_id ); ?> name="<?php echo esc_attr( $name ); ?>">
		<?php foreach ( $options as $value => $label ): ?>
			<option <?php selected( $selected, $value ); ?> value="<?php echo esc_attr( $value ); ?>"><?php echo esc_html( $label ); ?></option>
		<?php endforeach; ?>
		</select>
		<?php
	}

	/**
	 * Verifies if the Given Event has RSVP restricted.
	 *
	 * @param  int  $event_id   The Event/Post ID (optional).
	 * @param  int  $ticket_id  The Ticket/RSVP ID (optional).
	 * @param  int  $user_id    A User ID (optional).
	 * @return boolean
	 */
	public function is_rsvp_restricted( $event_id = null, $ticket_id = null, $user_id = null ) {
		// By default we always pass the current User
		if ( is_null( $user_id ) ) {
			$user_id = get_current_user_id();
		}

		/**
		 * Allow users to filter if this Event or Ticket has Restricted RSVP
		 *
		 * @param  boolean  $restricted Is this Event or Ticket Restricted?
		 * @param  int      $event_id   The Event/Post ID (optional)
		 * @param  int      $ticket_id  The Ticket/RSVP ID (optional)
		 * @param  int      $user_id    An User ID (optional)
		 */
		return apply_filters( 'event_tickets_is_rsvp_restricted', false, $event_id, $ticket_id, $user_id );
	}

	/**
	 * Gets a HTML Attribute for input/select/textarea to be disabled.
	 *
	 * @param  int  $event_id   The Event/Post ID (optional).
	 * @param  int  $ticket_id  The Ticket/RSVP ID (optional).
	 * @return boolean
	 */
	public function get_restriction_attr( $event_id = null, $ticket_id = null ) {
		$is_disabled = '';

		if ( $this->is_rsvp_restricted( $event_id, $ticket_id ) ) {
			$is_disabled = 'disabled title="' . esc_attr( sprintf( __( 'This %s is no longer active.', 'event-tickets' ), tribe_get_rsvp_label_singular( 'rsvp_restricted_title_text' ) ) ) . '"';
		}

		return $is_disabled;
	}

	/**
	 * Creates the HTML for the status of the  RSVP choice.
	 *
	 * @param  string $name     The Name of the Field.
	 * @param  string $selected The Current selected option.
	 * @param  int  $event_id   The Event/Post ID (optional).
	 * @param  int  $ticket_id  The Ticket/RSVP ID (optional).
	 * @return void
	 */
	public function render_rsvp_status( $name, $selected, $event_id = null, $ticket_id = null ) {
		$options = $this->get_rsvp_options();
		echo sprintf( '<span>%s</span>', esc_html( $options[ $selected ] ) );
	}

	/**
	 * Prunes RSVP options that are arrays and are not defining a label.
	 *
	 * @param array|string $option
	 *
	 * @return bool
	 */
	protected function has_rsvp_format( $option ) {
		if ( ! is_array( $option ) ) {
			return true;
		}

		// label is the bare minimum
		if ( ! isset( $option['label'] ) ) {
			return false;
		}

		return empty( $option['decrease_stock_by'] )
		       || (
					is_numeric( $option['decrease_stock_by'] )
		            && intval( $option['decrease_stock_by'] ) == $option['decrease_stock_by']
		            && intval( $option['decrease_stock_by'] ) >= 0
		       );
	}

	/**
	 * Normalizes the RSVP option conforming it to the array format.
	 *
	 * @param array|string $option
	 */
	protected function normalize_rsvp_option( &$option ) {
		$label_only_format = ! is_array( $option );
		if ( $label_only_format ) {
			$option = [ 'label' => $option, 'decrease_stock_by' => 1 ];
		} else {
			$option['decrease_stock_by'] = isset( $option['decrease_stock_by'] ) ? $option['decrease_stock_by'] : 1;
		}
	}

	/**
	 * Gets the block template "out of context" and makes it useable for non-gutenberg views.
	 *
	 * @param WP_Post|int $post The post object or ID.
	 * @param boolean     $echo Whether to echo the output or not.
	 *
	 * @return string The block HTML.
	 */
	public function get_tickets_block( $post, $echo = true ) {
		if ( empty( $post ) ) {
			return '';
		}

		if ( is_numeric( $post ) ) {
			$post = get_post( $post );
		}

		if (
			empty( $post )
			|| ! ( $post instanceof WP_Post )
		) {
			return '';
		}

		// if password protected then do not display content
		if ( post_password_required() ) {
			return '';
		}

		$post_id     = $post->ID;
		$provider_id = Tribe__Tickets__Tickets::get_event_ticket_provider( $post_id );

		// Protect against ticket that exists but is of a type that is not enabled
		if ( ! method_exists( $provider_id, 'get_instance' ) ) {
			return '';
		}

		$provider = call_user_func( [ $provider_id, 'get_instance' ] );

		/** @var \Tribe__Tickets__Editor__Template $template */
		$template = tribe( 'tickets.editor.template' );

		/** @var \Tribe__Tickets__Editor__Blocks__Tickets $blocks_tickets */
		$blocks_tickets = tribe( 'tickets.editor.blocks.tickets' );

		// Load assets manually.
		$blocks_tickets->assets();

		$tickets = $provider->get_tickets( $post_id );

		$args = [
			'post_id'             => $post_id,
			'provider'            => $provider,
			'provider_id'         => $provider_id,
			'tickets'             => $tickets,
			'cart_classes'        => [ 'tribe-block', 'tribe-tickets' ],
			'tickets_on_sale'     => $blocks_tickets->get_tickets_on_sale( $tickets ),
			'has_tickets_on_sale' => tribe_events_has_tickets_on_sale( $post_id ),
			'is_sale_past'        => $blocks_tickets->get_is_sale_past( $tickets ),
		];

		// Add the rendering attributes into global context.
		$template->add_template_globals( $args );

		// Enqueue assets.
		tribe_asset_enqueue( 'tribe-tickets-gutenberg-tickets' );
		tribe_asset_enqueue( 'tribe-tickets-gutenberg-block-tickets-style' );

		return $template->template( 'blocks/tickets', $args, $echo );
	}

	/**
	 * Gets the RSVP block template "out of context" and makes it usable for Classic views.
	 *
	 * @since TBD
	 *
	 * @param WP_Post|int $post The post object or ID.
	 * @param boolean     $echo Whether to echo the output or not.
	 *
	 * @return string The block HTML.
	 */
	public function get_rsvp_block( $post, $echo = true ) {
		if ( empty( $post ) ) {
			return '';
		}

		if ( is_numeric( $post ) ) {
			$post = get_post( $post );
		}

		if (
			empty( $post )
			|| ! ( $post instanceof WP_Post )
		) {
			return '';
		}

		// If password protected then do not display content.
		if ( post_password_required( $post ) ) {
			return '';
		}

		$post_id = $post->ID;

		/** @var \Tribe__Tickets__Editor__Template $template */
		$template = tribe( 'tickets.editor.template' );

		/** @var \Tribe__Tickets__Editor__Blocks__Rsvp $blocks_rsvp */
		$blocks_rsvp = tribe( 'tickets.editor.blocks.rsvp' );

		/** @var Tribe__Tickets__RSVP $rsvp */
		$rsvp = tribe( 'tickets.rsvp' );

		// Load assets manually.
		$blocks_rsvp->assets();

		$tickets        = $blocks_rsvp->get_tickets( $post_id );
		$active_tickets = $blocks_rsvp->get_active_tickets( $tickets );
		$past_tickets   = $blocks_rsvp->get_all_tickets_past( $tickets );

		$args = [
			'post_id'          => $post_id,
			'attributes'       => $blocks_rsvp->attributes(),
			'active_rsvps'     => $active_tickets,
			'all_past'         => $past_tickets,
			'has_rsvps'        => ! empty( $tickets ),
			'has_active_rsvps' => ! empty( $active_tickets ),
			'must_login'       => ! is_user_logged_in() && $rsvp->login_required(),
			'login_url'        => Tribe__Tickets__Tickets::get_login_url( $post_id ),
			'threshold'        => $blocks_rsvp->get_threshold( $post_id ),
		];

		// Add the rendering attributes into global context.
		$template->add_template_globals( $args );

		// @todo Remove this after G20.07.
		// Determine whether to show the previews on the page.
		if (
			defined( 'TRIBE_TICKETS_RSVP_NEW_VIEWS_PREVIEW' )
			&& TRIBE_TICKETS_RSVP_NEW_VIEWS_PREVIEW
		) {
			// Enqueue new assets.
			tribe_asset_enqueue( 'tribe-tickets-rsvp-style' );
			tribe_asset_enqueue( 'tribe-tickets-form-style' );
			// @todo: Remove this once we solve the common breakpoints vs container based.
			tribe_asset_enqueue( 'tribe-common-responsive' );

			return $template->template( 'v2/rsvp-kitchen-sink', $args, $echo );
		}

		// Maybe render the new views.
		if ( tribe_tickets_rsvp_new_views_is_enabled() ) {
			// Enqueue new assets.
			tribe_asset_enqueue( 'tribe-tickets-rsvp' );
			tribe_asset_enqueue( 'tribe-tickets-rsvp-style' );
			tribe_asset_enqueue( 'tribe-tickets-form-style' );
			// @todo: Remove this once we solve the common breakpoints vs container based.
			tribe_asset_enqueue( 'tribe-common-responsive' );

			return $template->template( 'v2/rsvp', $args, $echo );
		}

		// Enqueue assets.
		tribe_asset_enqueue( 'tribe-tickets-gutenberg-rsvp' );
		tribe_asset_enqueue( 'tribe-tickets-gutenberg-block-rsvp-style' );

		return $template->template( 'blocks/rsvp', $args, $echo );
	}
}
