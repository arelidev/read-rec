<?php
	_deprecated_file( __FILE__, '3.10', 'Tribe__Tickets__Ticket_Object' );


	class TribeEventsTicketObject extends Tribe__Tickets__Ticket_Object {

	}